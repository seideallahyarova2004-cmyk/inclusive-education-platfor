# Rəqəmsal Məktəb — veb saytı

Təkrar istifadə oluna bilən, tam işlək veb sayt. TanStack Start (React 19 +
TypeScript + Vite) və Tailwind CSS v4 ilə qurulub.

## Strukturu

```
src/
  routes/index.tsx     bütün səhifənin məzmunu (banner, bölmələr, footer)
  routes/__root.tsx    ümumi layout, head (başlıq, təsvir, og:image)
  styles.css           rənglər, şriftlər, dizayn dəyişənləri
  assets/              şagird, valideyn, müəllim, direktor şəkilləri
  components/ui/       düymə, kart, accordion və s. hazırl komponentlər
public/                favicon.ico, robots.txt
```

## Lokalda işə salmaq

Əvvəlcə Node.js quraşdırın (nvm ilə:
https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <repo-unvaniniz>
cd <repo-adiniz>
npm install
npm run dev
```

Səhifə `http://localhost:8080` ünvanında açılır.

Yoxlamaq üçün:

```sh
npm run build     # production build
npm run lint      # kod yoxlaması
npm test          # testlər
```

## GitHub-a yükləmək

1. GitHub-da boş (boş README-li) yeni repository yaradın.
2. Bu qovluqda aşağıdakıları icra edin:

```sh
git init
git add .
git commit -m "Rəqəmsal Məktəb veb saytı"
git branch -M main
git remote add origin https://github.com/<istifadeci>/<repo>.git
git push -u origin main
```

Açar sözlə (personal access token) itəlirsənizsə, GitHub sizdən token
istəyəcək — parol yox.

## Canlına çıxarmaq (pulsuz)

- **Vercel:** vercel.com-da GitHub repo-nu seçin — framework `Vite` avtomatik
  tanınır, build əmri `npm run build`, çıxış qovluğu `dist`.
- **Netlify:** build əmri `npm run build`, publish qovluğu `dist`.
- **GitHub Pages:** bu sayt server komponentləri işlədirdiyi üçün Pages-də
  yalnız statik versiya işləyər; Vercel və ya Netlify daha uyğundur.

## Qeyd

`node_modules`, `dist` və `tsconfig.tsbuildinfo` `.gitignore`-da olduğu üçün
repo-ya düşmür — bunlar quraşdırma zamanı yenidən yaranır.
