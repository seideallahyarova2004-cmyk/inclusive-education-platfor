import { createFileRoute } from "@tanstack/react-router";
import { BookOpen, MessageCircle, PlayCircle, CheckCircle2, Table, Award, Play, Menu, Phone, Globe, ArrowUpRight } from "lucide-react";
import student from "@/assets/student.png";
import parent from "@/assets/parent.png";
import teacher from "@/assets/teacher.png";
import director from "@/assets/director.png";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Rəqəmsal Məktəb — Rəqəmsal məktəb platforması" },
      { name: "description", content: "Rəqəmsal mühitdə öyrənmə, tədris, ünsiyyət və əməkdaşlıq platformasıdır." },
      { property: "og:title", content: "Rəqəmsal Məktəb" },
      { property: "og:description", content: "Rəqəmsal mühitdə öyrənmə, tədris, ünsiyyət və əməkdaşlıq platformasıdır." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const btnPrimary = "inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3 text-sm font-bold text-primary-foreground transition hover:bg-secondary";
const btnLight = "inline-flex items-center gap-2 rounded-full bg-card px-5 py-2.5 text-sm font-semibold text-foreground transition hover:bg-accent";

function Logo({ light }: { light?: boolean }) {
  return (
    <a href="/" className={`flex items-center gap-2 text-xl font-extrabold ${light ? "text-primary-foreground" : "text-primary"}`}>
      <span className="grid h-10 w-10 place-items-center rounded-xl bg-accent text-accent-foreground">R</span>
      Rəqəmsal Məktəb
    </a>
  );
}

function SectionHead({ title, desc, href }: { title: string; desc?: string; href?: string }) {
  return (
    <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
      <div className="max-w-2xl">
        <h3 className="text-3xl font-extrabold text-foreground md:text-4xl">{title}</h3>
        {desc && <p className="mt-3 text-muted-foreground">{desc}</p>}
      </div>
      {href && <a href={href} className={`${btnPrimary} hidden lg:inline-flex`}>Davam et <ArrowUpRight className="h-4 w-4" /></a>}
    </div>
  );
}

function Item({ icon, title, desc, tone = "bg-primary text-primary-foreground" }: { icon: React.ReactNode; title: string; desc: string; tone?: string }) {
  return (
    <div className="flex gap-4 rounded-3xl bg-card p-5">
      <div className={`grid h-14 w-14 shrink-0 place-items-center rounded-2xl text-lg font-extrabold ${tone}`}>{icon}</div>
      <div>
        <h5 className="font-bold text-foreground">{title}</h5>
        <p className="mt-1 text-sm text-muted-foreground">{desc}</p>
      </div>
    </div>
  );
}

function Person({ img, label, tone, offset }: { img: string; label: string; tone: string; offset?: boolean }) {
  return (
    <div className={`relative flex flex-col items-center ${offset ? "md:mt-16" : ""}`}>
      <div className={`relative h-64 w-full overflow-hidden rounded-[2.5rem] md:h-80 ${tone}`}>
        <img src={img} alt={label} width={768} height={1024} className="absolute bottom-0 left-1/2 h-[110%] w-auto max-w-none -translate-x-1/2 object-contain" />
      </div>
      <span className="-mt-5 relative rounded-full bg-card px-5 py-2 text-sm font-bold text-foreground shadow-lg">{label}</span>
    </div>
  );
}

const cards = [
  { icon: <BookOpen className="h-10 w-10" />, t: "Məktəbdə keçirilən dərsləri onlayn mükəmməlləşdir.", d: "Hazırlanmış tapşırıqları və test tapşırıqlarını yerinə yetirərək keçilmiş mövzuları möhkəmləndirə bilərsiniz.", c: "bg-secondary text-secondary-foreground", w: "md:col-span-7" },
  { icon: <MessageCircle className="h-10 w-10" />, t: "Müəllimlərdən soruş.", d: "Mövzu ilə bağlı müəllimlərə sual verə bilərsiniz.", c: "bg-pink text-foreground", w: "md:col-span-5" },
  { icon: <PlayCircle className="h-10 w-10" />, t: "Video dərslər və elektron dərsliklər.", d: "Mövzuların video izahını izləyə bilərsiniz.", c: "bg-accent text-accent-foreground", w: "md:col-span-5" },
  { icon: <CheckCircle2 className="h-10 w-10" />, t: "Özünü qiymətləndirmə.", d: "Dərsi tam anladığını yoxlaya bilərsiniz.", c: "bg-primary text-primary-foreground", w: "md:col-span-7" },
];

const videos = [
  { cat: "İnformasiya təhlükəsizliyinin artırılması", t: "Şifrənin təyin olunması qaydası", href: "https://www.youtube.com/watch?v=G7JqMn6OYHk", c: "bg-secondary" },
  { cat: "STEAM Muzeyinin rəqəmsallaşdırılması", t: "VR və AR otaqları", href: "https://www.youtube.com/watch?v=7I3FXZ5M45M", c: "bg-pink" },
  { cat: "İqlim dəyişikliyi - COP29", t: "COP29 - İqlim və hava. Fərqi bilirsinizmi? (böyük yaş qrupu)", href: "https://www.youtube.com/watch?v=6o-ZuLJ0cyA", c: "bg-accent" },
];

const links = [
  ["MÜTDA", "https://linktr.ee/mutda.edu.az"],
  ["Azərbaycan müəllimi", "https://linktr.ee/muallim.edu.az"],
  ["Təhsil TV", "https://linktr.ee/tehsiltv"],
  ["Təhsil Sisteminin İnformasiyallaşdırılması İdarəsi", "https://ict.edu.az/az"],
  ["Bakı Şəhəri üzrə Təhsil İdarəsi", "https://baku.edu.gov.az/"],
];

const socials = [
  ["Facebook", "https://www.facebook.com/tehsil.gov.az/"],
  ["Twitter", "https://x.com/tehsilgovaz"],
  ["Instagram", "https://www.instagram.com/edugovaz/"],
  ["Linkedin", "https://www.linkedin.com/company/edugovaz"],
  ["Youtube", "https://www.youtube.com/@tehsilgovaz"],
  ["Whatsapp Channel", "https://www.whatsapp.com/channel/0029VaFIDCK0LKZJNLcElO0o"],
  ["Telegram", "https://t.me/edugovaz"],
  ["Tiktok", "https://www.tiktok.com/@edugovaz"],
];

const wrap = "mx-auto max-w-7xl px-4 md:px-8";

function Index() {
  return (
    <main className="font-sans">
      {/* Header + Hero */}
      <section className="relative overflow-hidden bg-primary pb-20 text-primary-foreground">
        <div className="pointer-events-none absolute -right-24 -top-24 h-96 w-96 rounded-full bg-secondary opacity-60 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-32 -left-24 h-96 w-96 rounded-full bg-pink opacity-30 blur-3xl" />
        <header className={`${wrap} relative flex items-center justify-between py-6`}>
          <Logo light />
          <nav className="hidden items-center gap-6 text-sm font-semibold lg:flex">
            <a href="#about" className="hover:text-accent">Layihə haqqında</a>
            <a href="#teaching-videos" className="hover:text-accent">Tədris videoları</a>
            <a href="#mapsBanner" className="hover:text-accent">Bakı şəhəri üzrə məktəblər</a>
            <a href="#faq" className="hover:text-accent">FAQ</a>
            <a href="https://www.youtube.com/watch?v=DkWzZ8tcpDk" className="hover:text-accent">İstifadəçi təlimatı</a>
            <button className="rounded-full bg-accent px-6 py-2.5 font-bold text-accent-foreground">Giriş</button>
          </nav>
          <Menu className="h-7 w-7 lg:hidden" />
        </header>
        <div className={`${wrap} relative pt-10 text-center`}>
          <h1 className="text-4xl font-extrabold md:text-6xl">Rəqəmsal məktəb platforması</h1>
          <p className="mx-auto mt-4 max-w-xl text-lg opacity-80">Rəqəmsal mühitdə öyrənmə, tədris, ünsiyyət və əməkdaşlıq platformasıdır.</p>
          <div className="mt-14 grid grid-cols-2 gap-6 md:grid-cols-4">
            <Person img={student} label="Şagird" tone="bg-accent" />
            <Person img={parent} label="Valideyn" tone="bg-pink" offset />
            <Person img={teacher} label="Müəllim" tone="bg-secondary" offset />
            <Person img={director} label="Direktor" tone="bg-card" />
          </div>
        </div>
      </section>

      {/* Students */}
      <section className={`${wrap} py-20`}>
        <SectionHead title="Şagirdlər üçün giriş" href="https://digital.edu.az/auth/pupil" />
        <div className="grid gap-6 lg:grid-cols-12">
          <div className="grid gap-6 md:grid-cols-12 lg:col-span-9">
            {cards.map((c) => (
              <div key={c.t} className={`${c.w} overflow-hidden rounded-3xl bg-card`}>
                <div className={`flex h-40 items-center justify-center ${c.c}`}>{c.icon}</div>
                <div className="p-6">
                  <div className="text-lg font-bold">{c.t}</div>
                  <p className="mt-2 text-sm text-muted-foreground">{c.d}</p>
                </div>
              </div>
            ))}
          </div>
          <div className="hidden overflow-hidden rounded-3xl bg-accent lg:col-span-3 lg:block">
            <img src={student} alt="Şagird" loading="lazy" width={768} height={1024} className="h-full w-full object-cover object-top" />
          </div>
        </div>
      </section>

      {/* Parents */}
      <section className="bg-muted py-20">
        <div className={wrap}>
          <SectionHead title="Valideynlər üçün giriş" href="https://digital.edu.az/auth/digital/login/parent" />
          <div className="grid gap-6 lg:grid-cols-12">
            <div className="overflow-hidden rounded-3xl bg-pink lg:col-span-4">
              <img src={parent} alt="Valideyn" loading="lazy" width={768} height={1024} className="h-80 w-full object-cover object-top lg:h-full" />
            </div>
            <div className="lg:col-span-8">
              <h3 className="text-2xl font-extrabold">Övladın barədə məlumatlı ol.</h3>
              <p className="mt-3 text-muted-foreground">Övladının təlim nəticələrini və həftəlik dərs cədvəlini görə bilir. Həmçinin övladının təhsil aldığı məktəbin rəhbərliyi ilə əks əlaqə qura bilir.</p>
              <div className="mt-8 grid gap-4 md:grid-cols-3">
                <Item icon="5+" title="Qiymətlərə bax." desc="Təlim prosesində əldə olunan nailiyyətlərə baxın." />
                <Item icon={<Table />} title="Dərs cədvəli." desc="Övladının həftəlik dərs cədvəlinə bax." tone="bg-accent text-accent-foreground" />
                <Item icon={<Award />} title="Məktəb barədə rəyini bildir." desc="Direktor ilə birbaşa əks-əlaqə yarat." tone="bg-pink text-foreground" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Teachers */}
      <section className={`${wrap} py-20`}>
        <SectionHead title="Müəllimlər üçün giriş" href="https://digital.edu.az/auth/digital/login/teacher" />
        <div className="grid items-center gap-6 lg:grid-cols-3">
          <div className="grid gap-4">
            <Item icon="1" title="Qiymətlərə bax." desc="Tədris etdiyi siniflər üzrə həftəlik dərs cədvəli." tone="bg-secondary text-secondary-foreground" />
            <Item icon="2" title="Şagirdlər." desc="Tədris apardığı siniflərin siyahısı." tone="bg-secondary text-secondary-foreground" />
          </div>
          <div className="order-last overflow-hidden rounded-[2.5rem] bg-secondary lg:order-none">
            <img src={teacher} alt="Müəllim" loading="lazy" width={768} height={1024} className="h-96 w-full object-cover object-top" />
          </div>
          <div className="grid gap-4">
            <Item icon="3" title="Dərs cədvəli." desc="Müəllimin tədris etdiyi fənn, həftəlik dərs yükü, şəxsi məlumatları." tone="bg-secondary text-secondary-foreground" />
            <Item icon="4" title="Jurnallar." desc="Elektron qiymətləndirmənin səmərəli təşkili və sənədləşmə prosesinin rəqəmsallaşması." tone="bg-secondary text-secondary-foreground" />
          </div>
        </div>
      </section>

      {/* Director */}
      <section className="bg-muted py-20">
        <div className={wrap}>
          <SectionHead title="Direktor üçün giriş" href="https://digital.edu.az/auth/digital/login/director" />
          <div className="grid gap-6 lg:grid-cols-3">
            <div className="rounded-3xl bg-primary p-8 text-primary-foreground">
              <div className="text-2xl font-extrabold">Tədris prosesinin bir məkandan idarə olunması.</div>
              <p className="mt-4 opacity-80">Şagird, müəllim və valideynlər haqqında ətraflı məlumata baxa bilir, məktəbin statistik göstəriciləri və ani hesabatların əldə edilməsi imkanı mövcuddur.</p>
            </div>
            <div className="grid gap-4">
              <Item icon="5+" title="Qiymətlərə bax." desc="Tədris jurnallarındakı formativ və summativ qiymətləndirmənin nəticələrini izləyir." />
              <Item icon={<Table />} title="Dərs cədvəli" desc="Məktəb üzrə bütün siniflərin və müəllimlərin dərs cədvəllərini təyin edə bilir." tone="bg-accent text-accent-foreground" />
              <Item icon={<Award />} title="Məktəb barədə rəylərə cavab ver" desc="Valideynlər tərəfindən ünvanlanmış müraciətlərə baxır və cavablandırır." tone="bg-pink text-foreground" />
            </div>
            <div className="overflow-hidden rounded-3xl bg-card">
              <img src={director} alt="Direktor" loading="lazy" width={768} height={1024} className="h-96 w-full object-cover object-top lg:h-full" />
            </div>
          </div>
        </div>
      </section>

      {/* Videos */}
      <section id="teaching-videos" className={`${wrap} py-20`}>
        <SectionHead title="Tədris videoları" desc="Bu bölmədə şagirdlər üçün əlavə tədris resursları - iqlim dəyişikliyi, davamlı inkişaf hədəfləri, STEAM yanaşması və digər faydalı videolar yer alır." />
        <div className="grid gap-6 md:grid-cols-3">
          {videos.map((v) => (
            <a key={v.t} href={v.href} target="_blank" rel="noreferrer" className="group overflow-hidden rounded-3xl bg-card">
              <div className={`relative grid aspect-video place-items-center ${v.c}`}>
                <span className="grid h-16 w-16 place-items-center rounded-full bg-card text-primary transition group-hover:scale-110"><Play className="h-7 w-7 fill-current" /></span>
              </div>
              <div className="p-6">
                <div className="text-xs font-bold uppercase tracking-wide text-secondary">{v.cat}</div>
                <div className="mt-2 font-bold">{v.t}</div>
              </div>
            </a>
          ))}
        </div>
      </section>

      {/* Links */}
      <section className="bg-muted py-20">
        <div className={wrap}>
          <SectionHead title="Faydalı keçidlər" desc="Bu bölmə istifadəçilərin məlumat axtarışını asanlaşdırmaq və lazımi resurslara sürətli çıxışını təmin etmək məqsədi daşıyır." />
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            {links.map(([t, h]) => (
              <a key={t} href={h} target="_blank" rel="noreferrer" className="flex min-h-32 items-start justify-between gap-4 rounded-3xl bg-card p-6 transition hover:bg-accent">
                <h4 className="font-bold">{t}</h4>
                <ArrowUpRight className="h-5 w-5 shrink-0" />
              </a>
            ))}
          </div>
        </div>
      </section>

      {/* Map */}
      <section id="mapsBanner" className={`${wrap} py-20`}>
        <SectionHead title="Bakı məktəblərinin kataloqu" desc="Bakı şəhəri üzrə ümumtəhsil müəssisələrinin ünvanı və əlaqə vasitələri" />
        <div className="mb-6 grid gap-4 md:grid-cols-3">
          <select className="rounded-full border border-input bg-card px-5 py-3"><option>Rayon seçin</option></select>
          <select disabled className="rounded-full border border-input bg-muted px-5 py-3"><option>Məktəb seçin</option></select>
        </div>
        <div className="overflow-hidden rounded-3xl">
          <iframe title="Bakı xəritəsi" className="aspect-[2/1] w-full" src="https://www.openstreetmap.org/export/embed.html?bbox=49.70%2C40.33%2C50.05%2C40.48&layer=mapnik" />
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-primary py-14 text-primary-foreground">
        <div className={wrap}>
          <div className="flex flex-wrap items-start justify-between gap-8">
            <Logo light />
            <div className="flex flex-wrap gap-3">
              <a href="tel:+994121464" className={btnLight}><Phone className="h-4 w-4" />+994 (12) 146 -4</a>
              <a href="https://edu.gov.az/" className={btnLight}><Globe className="h-4 w-4" />www.edu.gov.az</a>
            </div>
          </div>
          <div className="mt-8 flex flex-wrap gap-3">
            {socials.map(([t, h]) => (
              <a key={t} href={h} target="_blank" rel="noreferrer" className="rounded-full border border-primary-foreground/30 px-4 py-2 text-sm hover:bg-primary-foreground/10">{t}</a>
            ))}
          </div>
          <div className="mt-10 flex flex-wrap items-center justify-between gap-4 border-t border-primary-foreground/20 pt-6 text-sm opacity-80">
            <a href="https://edu.gov.az/" className="font-bold">Elm və Təhsil Nazirliyi</a>
            <p>Bütün hüquqlar qorunur © {new Date().getFullYear()}</p>
          </div>
        </div>
      </footer>
    </main>
  );
}
